﻿

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

public class Account
{
    [Key]
    public int AccountId { get; set; }

    [Required]
    public string AccountNumber { get; set; } = string.Empty;

    [Required]
    public string AccountHolder { get; set; } = string.Empty;

    [Required]
    public decimal Balance { get; set; }
}