﻿
using System;
using System.Collections.Generic;
using BankingPersistences.Entities;
using Microsoft.EntityFrameworkCore;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace BankingPersistences.DataContext
{
    public class BankContext : DbContext
    {
        public BankContext()
        {

        }
        public BankContext(DbContextOptions<BankContext> options) : base(options) { }
        public DbSet<Account> Accounts { get; set; }
        public DbSet<Transaction> Transactions { get; set; }

    }
}
