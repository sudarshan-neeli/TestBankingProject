﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingPersistences.Entities
{
    public class Account
    {
        public int AccountId { get; set; }

        public string AccountNumber { get; set; } = string.Empty;

        public string AccountHolder { get; set; } = string.Empty;

        public decimal Balance { get; set; }
    }
}
