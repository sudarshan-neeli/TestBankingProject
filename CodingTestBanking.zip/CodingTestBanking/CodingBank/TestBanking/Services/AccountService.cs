﻿using BankingPersistences.Entities;
using TestBanking.Interfaces;
using BankingPersistences.Entities;
using BankingPersistences.DataContext;
using Microsoft.EntityFrameworkCore;
using TestBanking.Models;
using Account = TestBanking.Models.Account;
using Microsoft.Identity.Client;
using Transaction = TestBanking.Models.Transaction;

namespace TestBanking.Services
{
    public class AccountService : IAccountService
    {
        private readonly BankContext _context;

        public AccountService(BankContext bankContext)
        {
            _context = bankContext;

        }

        public async Task<int> CreateAccount(Account account)
        {
           BankingPersistences.Entities.Account accountInfo = new BankingPersistences.Entities.Account()
           {
               AccountId=account.AccountId,
               AccountNumber=account.AccountNumber,
               AccountHolder=account.AccountHolder,
           };
           var _account= _context.Accounts.Add(accountInfo);
           var _accountID= await _context.SaveChangesAsync();
            return _accountID;
        }

        public async Task<Account> GetAccountBalence(int accountID)
        {
            Account accountBalence = new Account();

            var _ExistsAccount =  await _context.Accounts.Where(x=>x.AccountId==accountID).FirstOrDefaultAsync();
            if(_ExistsAccount != null)
            {
                accountBalence.AccountNumber = _ExistsAccount.AccountNumber;
                accountBalence.AccountId = _ExistsAccount.AccountId;
                accountBalence.AccountHolder = _ExistsAccount.AccountHolder;
                accountBalence.Balance=_ExistsAccount.Balance;
            }
            return accountBalence;
        }

        public async Task<Account> GetAccounts()
        {
            Account account = new Account();
            var _acc = await _context.Accounts.ToListAsync();
            foreach (var item in _acc)
            {
                account.AccountNumber = item.AccountNumber;
                account.AccountId = item.AccountId;
                account.AccountHolder = item.AccountHolder;

            }
            return account;
        }

       

        public async Task<bool> TransferFunds(TransferFunds transferFunds)
        {
            var _fromAccount = await _context.Accounts.FindAsync(transferFunds._FromAccount.AccountId);
            var _toAccount = await _context.Accounts.FindAsync(transferFunds._ToAccount.AccountId);

            if (_fromAccount == null || _toAccount == null) 
            {
                return false;
            }
            if (_fromAccount.Balance < transferFunds._amt) 
            {
                return false;
            }

            _fromAccount.Balance -= transferFunds._amt;
            _toAccount.Balance += transferFunds._amt;

            _context.Transactions.Add(new BankingPersistences.Entities.Transaction
            {
                AccountId = _fromAccount.AccountId,
                Amount = - _fromAccount .Balance,
                Type = "Transfer"
            });

            _context.Transactions.Add(new BankingPersistences.Entities.Transaction
            {
                AccountId = _toAccount.AccountId,
                Amount = _toAccount.Balance,
                Type = "Transfer"
            });

            await _context.SaveChangesAsync();
            return true;
        }

         async Task<Transaction> IAccountService.RecentTransaction(int accountID)
        {
            Transaction transaction = new Transaction();
            var _trasaction = await _context.Transactions.Where(x => x.AccountId == accountID).ToListAsync();
            if (_trasaction != null)
            {
                foreach (var item in _trasaction)
                {
                    transaction.TransactionId = item.TransactionId;
                    transaction.AccountId = item.AccountId;
                    transaction.Date = item.Date;
                }

            }
            return transaction;
        }
    }
}
