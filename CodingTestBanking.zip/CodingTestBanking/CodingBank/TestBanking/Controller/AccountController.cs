﻿using BankingPersistences.DataContext;
using BankingPersistences.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Metadata;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using TestBanking.Interfaces;
using TestBanking.Models;
using Account = TestBanking.Models.Account;

namespace TestBanking.Controller
{
    [Route("api/accounts")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IAccountService _accountService;

        public AccountController(IAccountService accountService)
        {
            _accountService = accountService;
        }

       

        [HttpGet("{id}")]
        [Authorize] 
        public async Task<IActionResult> GetAccountBalence(int id)
        {
            return Ok(await _accountService.GetAccountBalence(id));

        }

        [HttpPost]
        [Authorize] 
        public async Task<IActionResult> CreateAccount(Account account)
        {
            
            return Ok(await _accountService.CreateAccount(account));
        }

        [HttpPost("transfer")]
        [Authorize] 

        public async Task<IActionResult> TransferFunds(TransferFunds transferFunds)
        {
            return Ok(await _accountService.TransferFunds(transferFunds));

        }

        [HttpGet("RecentTransactions")]
        [Authorize]

        public async Task<IActionResult> RecentTrasaction(int accountID)
        {
            return Ok(await _accountService.RecentTransaction(accountID));
        }
    }
}
