﻿using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using TestBanking.Authentication;
using TestBanking.Models;
using LoginRequest = TestBanking.Models.LoginRequest;
namespace TestBanking.Controller
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly TokenService _tokenService;

        public AuthController(TokenService tokenService)
        {
            _tokenService = tokenService;

        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequest request)
        {
            if (request.Username == "testuser" && request.Password == "password123") 
            {
                var token = _tokenService.GenerateToken(request.Username);
                return Ok(new { Token = token });
            }
            return Unauthorized("Invalid credentials");
        }
    }
}
