﻿using System.ComponentModel.DataAnnotations;

namespace TestBanking.Models
{
    public class Usercs
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Username { get; set; } = string.Empty;

        [Required]
        public string Password { get; set; } = string.Empty;

        public string Role { get; set; } = "User"; // Default role is "User"
    }
}
