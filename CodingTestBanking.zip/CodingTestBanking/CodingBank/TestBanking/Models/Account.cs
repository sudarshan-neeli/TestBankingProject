﻿using System.ComponentModel.DataAnnotations;

namespace TestBanking.Models
{
    public class Account
    {
        [Key]
        public int AccountId { get; set; }

        [Required]
        public string AccountNumber { get; set; } = string.Empty;

        [Required]
        public string AccountHolder { get; set; } = string.Empty;

        [Required]
        public decimal Balance { get; set; }
        public string Note { get; set; }

    }
}
