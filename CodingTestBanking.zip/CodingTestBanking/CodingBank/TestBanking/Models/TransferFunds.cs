﻿namespace TestBanking.Models
{
    public class TransferFunds
    {
        public Account _FromAccount { get; set; }
        public Account _ToAccount { get; set; }
        public decimal _amt { get; set; }
        public DateTime _trasactionDate { get; set; }
        public string Note { get; set; }



    }
}
