﻿using BankingPersistences.Entities;
using Microsoft.Identity.Client;
using TestBanking.Models;
using Account = TestBanking.Models.Account;
using Transaction = TestBanking.Models.Transaction;

namespace TestBanking.Interfaces
{
    public interface IAccountService
    {
        Task<Account> GetAccounts();
        Task<Account> GetAccountBalence(int accountID);

        Task<bool> TransferFunds(TransferFunds transferFunds);
        Task<int> CreateAccount(Account account);
        Task<Transaction> RecentTransaction(int accountID);
    }
}
