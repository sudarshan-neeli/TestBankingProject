﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using System.Transactions;
using TestBankingUI.Models;

namespace TestBankingUI.Controllers
{
    public class ViewTransactionController : Controller
    {
        private readonly HttpClient _httpClient;
        public ViewTransactionController()
        {
                _httpClient = new HttpClient();
        }

        public async Task<IActionResult> ViewTransactions()
        {
            var token = Request.Cookies["AuthToken"];
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            int Account_number = 1222;

            var response = await _httpClient.GetAsync($"http://localhost:7002/api/accounts/RecentTransactions?accountNumber{Account_number}");
            List<TransactionViewModel> lstTransactionViewModels = new List<TransactionViewModel>
            {
                new TransactionViewModel
                {
                    FromAccountId = "004001604430",
                    ToAccountId = "324599800124",
                    Mode = "Debited",
                    Amount = 400,
                    TransactionDate = DateTime.UtcNow
                },
                new TransactionViewModel
                {
                    FromAccountId = "778800112233",
                    ToAccountId = "998877665544",
                    Mode = "Credited",
                    Amount = 1500,
                    TransactionDate = DateTime.UtcNow.AddDays(-2)
                },
                new TransactionViewModel
                {
                    FromAccountId = "112233445566",
                    ToAccountId = "223344556677",
                    Mode = "Debited",
                    Amount = 750,
                    TransactionDate = DateTime.UtcNow.AddDays(-5)
                },
                new TransactionViewModel
                {
                    FromAccountId = "556677889900",
                    ToAccountId = "667788990011",
                    Mode = "Credited",
                    Amount = 3000,
                    TransactionDate = DateTime.UtcNow.AddDays(-10)
                }
            };

            return View(lstTransactionViewModels);
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
