using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Reflection;
using System.Security.Principal;
using TestBankingUI.Models;

namespace TestBankingUI.Controllers
{
    public class HomeController : Controller
    {
        private readonly HttpClient _httpClient;

        public HomeController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }


        public async Task<IActionResult> Dashboard()
        {
            var token = Request.Cookies["AuthToken"];
            int Account_number = 1222;
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var response = await _httpClient.GetAsync($"http://localhost:7002/api/accounts?accountNumber={Account_number}");



            ViewBag.Username = "Sudarshan Neeli";
            ViewBag.Balance = "99999.00 INR";

            return View();
        }
    }
}
