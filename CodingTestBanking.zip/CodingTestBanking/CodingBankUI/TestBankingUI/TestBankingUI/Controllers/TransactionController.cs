﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using System.Transactions;
using TestBankingUI.Models;

namespace TestBankingUI.Controllers
{
    public class TransactionController : Controller
    {
        private readonly HttpClient _httpClient;

        public TransactionController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public IActionResult Transfer() => View();

        [HttpPost]
        public async Task<IActionResult> Transfer(TransferViewModel model)
        {
            if (!ModelState.IsValid)
            {

                var token = Request.Cookies["AuthToken"];
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.PostAsJsonAsync("http://localhost:7002/api/accounts/transfer", model);
                if (response.IsSuccessStatusCode) return RedirectToAction("Dashboard", "Home");

                ViewBag.Error = "Transfer failed";
                return View();
            }
            TempData["Success"] = "Transfer successful!";
            return RedirectToAction("Dashboard", "Home");
        }

        
    }
}
