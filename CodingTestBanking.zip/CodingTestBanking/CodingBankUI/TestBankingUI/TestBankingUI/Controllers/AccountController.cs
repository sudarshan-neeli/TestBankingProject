﻿using Microsoft.AspNetCore.Mvc;
using TestBankingUI.Models;

namespace TestBankingUI.Controllers
{
    public class AccountController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _config;

        public AccountController(HttpClient httpClient, IConfiguration config)
        {
            _httpClient = httpClient;
            _config = config;
        }

        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:7002/api/auth/login", model);

            if (!response.IsSuccessStatusCode)
            {
                ViewBag.Error = "Invalid username or password";
                return View(model);
            }

            var result = await response.Content.ReadFromJsonAsync<TokenResponse>();
            Response.Cookies.Append("AuthToken", result.Token, new CookieOptions { HttpOnly = true });

            return RedirectToAction("Dashboard", "Home");
        }

        public IActionResult Logout()
        {
            Response.Cookies.Delete("AuthToken");
            return RedirectToAction("Login");
        }
    }
}
