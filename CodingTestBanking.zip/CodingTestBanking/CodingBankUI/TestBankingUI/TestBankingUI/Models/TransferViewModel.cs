﻿namespace TestBankingUI.Models
{
    using System.ComponentModel.DataAnnotations;
    using System.Security.Principal;

    public class TransferViewModel
    {
        [Required(ErrorMessage = "Sender account is required")]
        public Account FromAccount { get; set; }

        [Required(ErrorMessage = "Recipient account is required")]
        public Account ToAccount { get; set; }

        [Required(ErrorMessage = "Amount is required")]
        [Range(1, double.MaxValue, ErrorMessage = "Amount must be greater than zero")]
        public decimal Amount { get; set; }

        [Required(ErrorMessage = "Transaction note is required")]
        [StringLength(100, ErrorMessage = "Note cannot exceed 100 characters")]
        public string Note { get; set; }
        public DateTime TransactionDate { get; set; }
    }

    public class Account
    {
        [Key]
        public int AccountId { get; set; }

        [Required]
        public string AccountNumber { get; set; } = string.Empty;

        [Required]
        public string AccountHolder { get; set; } = string.Empty;

        [Required]
        public decimal Balance { get; set; }
    }
}
