﻿namespace TestBankingUI.Models
{
    public class TransactionViewModel
    {
        public string FromAccountId { get; set; }
        public string ToAccountId { get; set; }
        public decimal Amount { get; set; }
        public DateTime TransactionDate { get; set; }
        public string Mode { get; set; } // "Credit" or "Debit"
    }
}
